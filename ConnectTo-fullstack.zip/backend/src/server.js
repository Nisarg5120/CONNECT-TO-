import express from "express";
import cors from "cors";
import { v4 as uuid } from "uuid";

const app = express();
app.use(cors());
app.use(express.json());

const users = [
  {
    id: "u1",
    name: "Aarav Mehta",
    headline: "Product Designer • Building useful digital products",
    location: "Pune, India",
    avatar: "https://i.pravatar.cc/150?img=12",
    skills: ["Product Design", "Figma", "UX Research"],
    about: "Designer focused on simple, accessible experiences.",
    followers: 842
  },
  {
    id: "u2",
    name: "Maya Shah",
    headline: "Software Engineer • AI & Cloud",
    location: "Bengaluru, India",
    avatar: "https://i.pravatar.cc/150?img=47",
    skills: ["React", "Node.js", "AI"],
    about: "Engineer building scalable developer tools.",
    followers: 1240
  },
  {
    id: "u3",
    name: "Rohan Kulkarni",
    headline: "Growth & Partnerships",
    location: "Mumbai, India",
    avatar: "https://i.pravatar.cc/150?img=68",
    skills: ["Growth", "Sales", "Partnerships"],
    about: "Helping technology teams turn ideas into sustainable businesses.",
    followers: 673
  }
];

let posts = [
  {
    id: "p1",
    authorId: "u1",
    text: "A good product should make the next step obvious. What small UX improvement made the biggest difference in your work?",
    createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    likes: 34,
    comments: 8,
    liked: false
  },
  {
    id: "p2",
    authorId: "u2",
    text: "Just shipped a small AI workflow that saves our team hours every week. The best automation is the one that quietly removes repetitive work.",
    createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    likes: 67,
    comments: 13,
    liked: false
  }
];

let opportunities = [
  { id:"j1", title:"Frontend Engineer", company:"Nova Labs", location:"Remote", type:"Full-time", skills:["React","TypeScript"] },
  { id:"j2", title:"Product Designer", company:"Orbit Studio", location:"Pune, India", type:"Full-time", skills:["Figma","UX"] },
  { id:"j3", title:"Growth Associate", company:"BrightStack", location:"Mumbai, India", type:"Hybrid", skills:["Growth","Analytics"] }
];

let connections = { u1: ["u2"], u2: ["u1"], u3: [] };

function enrichPost(p) {
  const author = users.find(u => u.id === p.authorId);
  return { ...p, author };
}

app.get("/api/health", (_, res) => res.json({ ok:true, name:"ConnectTo API" }));
app.get("/api/users", (_, res) => res.json(users));
app.get("/api/users/:id", (req,res) => {
  const user=users.find(u=>u.id===req.params.id);
  if(!user) return res.status(404).json({message:"Profile not found"});
  res.json(user);
});

app.get("/api/feed", (_,res) => res.json(posts.map(enrichPost)));

app.post("/api/posts", (req,res) => {
  const { authorId="u1", text="" }=req.body;
  if(!text.trim()) return res.status(400).json({message:"Post text is required"});
  const post={id:uuid(),authorId,text:text.trim(),createdAt:new Date().toISOString(),likes:0,comments:0,liked:false};
  posts.unshift(post);
  res.status(201).json(enrichPost(post));
});

app.post("/api/posts/:id/like", (req,res) => {
  const post=posts.find(p=>p.id===req.params.id);
  if(!post) return res.status(404).json({message:"Post not found"});
  post.liked=!post.liked;
  post.likes += post.liked ? 1 : -1;
  res.json(enrichPost(post));
});

app.get("/api/opportunities", (req,res) => {
  const q=(req.query.q||"").toLowerCase();
  const result=opportunities.filter(j => !q || [j.title,j.company,j.location,...j.skills].join(" ").toLowerCase().includes(q));
  res.json(result);
});

app.post("/api/opportunities/:id/apply", (req,res) => {
  const job=opportunities.find(j=>j.id===req.params.id);
  if(!job) return res.status(404).json({message:"Opportunity not found"});
  res.json({success:true,message:`Application recorded for ${job.title} at ${job.company}.`});
});

app.get("/api/connections/:id", (req,res) => {
  const ids=connections[req.params.id]||[];
  res.json(users.filter(u=>ids.includes(u.id)));
});

app.post("/api/connections/:id", (req,res) => {
  const target=req.params.id;
  if(!users.some(u=>u.id===target)) return res.status(404).json({message:"User not found"});
  connections.u1 ||= [];
  if(!connections.u1.includes(target)) connections.u1.push(target);
  connections[target] ||= [];
  if(!connections[target].includes("u1")) connections[target].push("u1");
  res.json({connected:true});
});

app.get("/api/search", (req,res) => {
  const q=(req.query.q||"").toLowerCase().trim();
  if(!q) return res.json({people:[], opportunities:[]});
  res.json({
    people: users.filter(u=>[u.name,u.headline,u.location,...u.skills].join(" ").toLowerCase().includes(q)),
    opportunities: opportunities.filter(j=>[j.title,j.company,j.location,...j.skills].join(" ").toLowerCase().includes(q))
  });
});

app.listen(5000, ()=>console.log("ConnectTo API running on http://localhost:5000"));
