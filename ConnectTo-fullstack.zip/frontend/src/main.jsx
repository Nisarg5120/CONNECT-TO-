import React,{useEffect,useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import {Search, Home, Users, BriefcaseBusiness, Bell, MessageCircle, Plus, Heart, MessageSquare, Share2, MapPin, Sparkles, Send, X} from "lucide-react";
import "./styles.css";

const API="http://localhost:5000/api";
const demoUser={id:"u1",name:"Aarav Mehta",headline:"Product Designer • Building useful digital products",location:"Pune, India",avatar:"https://i.pravatar.cc/150?img=12",skills:["Product Design","Figma","UX Research"],followers:842};

async function get(path){const r=await fetch(API+path); return r.json();}
async function post(path,body={}){const r=await fetch(API+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}); return r.json();}

function Avatar({src,name,size="md"}){return <img className={"avatar "+size} src={src} alt={name}/>}

function Header({page,setPage,onSearch}) {
  const [q,setQ]=useState("");
  return <header className="topbar">
    <div className="brand" onClick={()=>setPage("home")}><span className="brandMark">C</span><span>connect<span className="brandAccent">to</span></span></div>
    <div className="searchBox"><Search size={18}/><input value={q} onChange={e=>{setQ(e.target.value);onSearch(e.target.value)}} placeholder="Search people, skills, opportunities"/></div>
    <nav>
      {[
        ["home",Home,"Home"],["network",Users,"Circles"],["opportunities",BriefcaseBusiness,"Opportunities"],["messages",MessageCircle,"Messages"],["notifications",Bell,"Alerts"]
      ].map(([id,I,label])=><button className={page===id?"navItem active":"navItem"} onClick={()=>setPage(id)} key={id}><I size={19}/><span>{label}</span></button>)}
    </nav>
    <button className="miniProfile" onClick={()=>setPage("profile")}><Avatar src={demoUser.avatar} name={demoUser.name} size="sm"/></button>
  </header>
}

function Sidebar({setPage}){return <aside className="leftCol">
  <section className="profileCard">
    <div className="cover"></div><Avatar src={demoUser.avatar} name={demoUser.name}/>
    <h3>{demoUser.name}</h3><p>{demoUser.headline}</p><div className="location"><MapPin size={14}/>{demoUser.location}</div>
    <div className="stats"><div><b>{demoUser.followers}</b><span>Followers</span></div><div><b>186</b><span>Circles</span></div></div>
    <button className="outlineBtn" onClick={()=>setPage("profile")}>View showcase</button>
  </section>
  <section className="sideCard"><h4>Your toolkit</h4><div className="skillCloud">{demoUser.skills.map(s=><span key={s}>{s}</span>)}</div></section>
  <div className="sideLinks"><span>About</span><span>Guidelines</span><span>Privacy</span><span>Help</span><small>© 2026 ConnectTo</small></div>
</aside>}

function RightRail({setPage}){return <aside className="rightCol">
  <section className="sideCard"><div className="cardTitle"><h3>People to meet</h3><button onClick={()=>setPage("network")}>See all</button></div>
    {["u2","u3"].map(id=><Person key={id} id={id} compact/>)}
  </section>
  <section className="sideCard tip"><Sparkles size={21}/><div><b>Build your showcase</b><p>Add a project or achievement to help your profile tell a stronger story.</p><button onClick={()=>setPage("profile")}>Add project →</button></div></section>
</aside>}

function Person({id,compact=false}) {
 const [u,setU]=useState(null); const [connected,setConnected]=useState(false);
 useEffect(()=>{get("/users/"+id).then(setU)},[id]);
 if(!u)return null;
 return <div className="person"><Avatar src={u.avatar} name={u.name} size="sm"/><div className="personInfo"><b>{u.name}</b><span>{u.headline}</span>{!compact&&<small>{u.location}</small>}</div>{compact?<button className="plusBtn" onClick={async()=>{await post("/connections/"+id);setConnected(true)}}>{connected?"✓":"+"}</button>:null}</div>
}

function Composer({onPosted}) {
 const [text,setText]=useState("");
 async function submit(){if(!text.trim())return; const p=await post("/posts",{authorId:"u1",text});setText("");onPosted(p)}
 return <section className="composer"><div className="composerTop"><Avatar src={demoUser.avatar} name={demoUser.name}/><button onClick={()=>document.querySelector(".composer textarea")?.focus()}>{text||"Share an idea, lesson, project or opportunity..."}</button></div>
 <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="What are you working on?"></textarea>
 <div className="composerActions"><div><button><Plus size={18}/>Media</button><button>📊 Poll</button><button>✨ Showcase</button></div><button className="primary small" onClick={submit}><Send size={16}/>Publish</button></div></section>
}

function PostCard({post,onLike}){return <article className="postCard"><div className="postHead"><Avatar src={post.author.avatar} name={post.author.name}/><div><b>{post.author.name}</b><span>{post.author.headline}</span><small>{new Date(post.createdAt).toLocaleString()}</small></div><button className="more">•••</button></div><p className="postText">{post.text}</p><div className="engagement"><span>♡ {post.likes}</span><span>{post.comments} conversations</span></div><div className="postActions"><button className={post.liked?"liked":""} onClick={()=>onLike(post.id)}><Heart size={18}/>{post.liked?"Liked":"Appreciate"}</button><button><MessageSquare size={18}/>Discuss</button><button><Share2 size={18}/>Share</button></div></article>}

function HomePage({setPage}) {
 const [posts,setPosts]=useState([]);
 useEffect(()=>{get("/feed").then(setPosts)},[]);
 async function like(id){const p=await post("/posts/"+id+"/like");setPosts(x=>x.map(v=>v.id===id?p:v))}
 return <><div className="feed"><Composer onPosted={p=>setPosts(x=>[p,...x])}/>{posts.map(p=><PostCard key={p.id} post={p} onLike={like}/>)}</div><RightRail setPage={setPage}/></>
}

function Network(){return <main className="fullPage"><div className="pageHero"><div><span className="eyebrow">YOUR CIRCLE</span><h1>People worth meeting</h1><p>Discover professionals by skills, interests and shared goals.</p></div><button className="primary">Find people</button></div><div className="peopleGrid">{["u1","u2","u3"].map(id=><div className="personCard" key={id}><div className="personBanner"></div><Avatar src={id==="u1"?demoUser.avatar:"https://i.pravatar.cc/150?img="+(id==="u2"?47:68)} name="person"/><h3>{id==="u1"?"Aarav Mehta":id==="u2"?"Maya Shah":"Rohan Kulkarni"}</h3><p>{id==="u1"?demoUser.headline:id==="u2"?"Software Engineer • AI & Cloud":"Growth & Partnerships"}</p><button className="outlineBtn">{id==="u1"?"Your profile":"Connect"}</button></div>)}</div></main>}

function Opportunities(){const [jobs,setJobs]=useState([]);const [q,setQ]=useState("");useEffect(()=>{get("/opportunities").then(setJobs)},[]);async function search(v){setQ(v);setJobs(await get("/opportunities?q="+encodeURIComponent(v)))}return <main className="fullPage"><div className="pageHero"><div><span className="eyebrow">OPPORTUNITIES</span><h1>Find your next move</h1><p>Roles, projects and collaborations matched to your toolkit.</p></div></div><div className="jobSearch"><Search size={18}/><input value={q} onChange={e=>search(e.target.value)} placeholder="Search roles, companies or skills"/></div><div className="jobList">{jobs.map(j=><div className="jobCard" key={j.id}><div className="companyLogo">{j.company[0]}</div><div className="jobInfo"><h3>{j.title}</h3><b>{j.company}</b><span>{j.location} · {j.type}</span><div>{j.skills.map(s=><em key={s}>{s}</em>)}</div></div><button className="primary" onClick={async()=>alert((await post("/opportunities/"+j.id+"/apply")).message)}>Apply</button></div>)}</div></main>}

function Profile(){return <main className="fullPage profilePage"><section className="profileHero"><div className="profileCover"></div><div className="profileBody"><Avatar src={demoUser.avatar} name={demoUser.name} size="xl"/><div className="profileMain"><span className="eyebrow">YOUR SHOWCASE</span><h1>{demoUser.name}</h1><h3>{demoUser.headline}</h3><p><MapPin size={15}/> {demoUser.location}</p></div><button className="outlineBtn">Edit showcase</button></div></section><div className="profileColumns"><div><section className="contentCard"><h2>About</h2><p>Designer focused on simple, accessible experiences. I enjoy turning complex problems into clear product journeys and collaborating with engineering and research teams.</p></section><section className="contentCard"><h2>Experience</h2><div className="timeline"><div><b>Product Designer · Nova Labs</b><span>2023 — Present</span><p>Leading product design for a collaborative workspace.</p></div><div><b>UX Designer · Studio North</b><span>2021 — 2023</span><p>Designed mobile and web experiences for growing teams.</p></div></div></section></div><aside><section className="contentCard"><h2>Toolkit</h2><div className="skillCloud">{demoUser.skills.concat(["Prototyping","Design Systems"]).map(s=><span key={s}>{s}</span>)}</div></section></aside></div></main>}

function Messages(){return <main className="fullPage"><div className="chatShell"><aside><h2>Messages</h2>{["Maya Shah","Rohan Kulkarni"].map((n,i)=><div className="chatPerson" key={n}><Avatar src={"https://i.pravatar.cc/150?img="+(i?68:47)} name={n} size="sm"/><div><b>{n}</b><span>{i?"Let's connect about the project":"The prototype looks great!"}</span></div></div>)}</aside><section className="chat"><div className="chatHeader"><Avatar src="https://i.pravatar.cc/150?img=47" name="Maya Shah" size="sm"/><div><b>Maya Shah</b><span>Online</span></div></div><div className="chatMessages"><div className="bubble">Hey Aarav! I liked your post about simple UX.</div><div className="bubble mine">Thanks! I'd love to compare notes on your AI workflow.</div></div><div className="chatInput"><input placeholder="Write a message..."/><button className="primary"><Send size={17}/></button></div></section></div></main>}

function SearchResults({q,setPage}){const [data,setData]=useState({people:[],opportunities:[]});useEffect(()=>{if(q)get("/search?q="+encodeURIComponent(q)).then(setData)},[q]);return <main className="fullPage"><div className="pageHero"><div><span className="eyebrow">SEARCH</span><h1>Results for “{q}”</h1></div></div>{data.people.length>0&&<section className="contentCard"><h2>People</h2>{data.people.map(u=><div className="person resultPerson" key={u.id}><Avatar src={u.avatar} name={u.name}/><div className="personInfo"><b>{u.name}</b><span>{u.headline}</span><small>{u.location}</small></div><button className="outlineBtn" onClick={()=>setPage("network")}>View</button></div>)}</section>}{data.opportunities.length>0&&<section className="contentCard"><h2>Opportunities</h2>{data.opportunities.map(j=><div className="jobCard compactJob" key={j.id}><div className="companyLogo">{j.company[0]}</div><div className="jobInfo"><h3>{j.title}</h3><b>{j.company}</b><span>{j.location}</span></div></div>)}</section>}</main>}

function App(){const [page,setPage]=useState("home");const [q,setQ]=useState("");const content=page==="home"?<HomePage setPage={setPage}/>:page==="network"?<Network/>:page==="opportunities"?<Opportunities/>:page==="profile"?<Profile/>:page==="messages"?<Messages/>:page==="search"?<SearchResults q={q} setPage={setPage}/>:<HomePage setPage={setPage}/>;return <><Header page={page} setPage={setPage} onSearch={v=>{setQ(v);if(v.trim())setPage("search")}}/><div className="layout">{page==="home"?<Sidebar setPage={setPage}/>:null}{content}</div></>}
createRoot(document.getElementById("root")).render(<App/>);
