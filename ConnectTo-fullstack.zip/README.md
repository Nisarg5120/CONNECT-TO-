# ConnectTo

An original professional networking platform inspired by the general idea of professional networking, with its own branding, UI, terminology and implementation.

## Run

### Backend
```bash
cd backend
npm install
npm run dev
```
Runs on http://localhost:5000

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Runs on http://localhost:5173

The frontend uses the backend API at `http://localhost:5000/api`.

## Demo
The app includes a local demo mode with seeded sample profiles, posts and opportunities. The backend stores data in memory so it is easy to run for a prototype. Replace the storage layer with PostgreSQL/MongoDB for production.
